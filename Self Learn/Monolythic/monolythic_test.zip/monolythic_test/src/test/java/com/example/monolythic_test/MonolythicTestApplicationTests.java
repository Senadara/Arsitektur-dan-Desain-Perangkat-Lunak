package com.example.monolythic_test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonolythicTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
