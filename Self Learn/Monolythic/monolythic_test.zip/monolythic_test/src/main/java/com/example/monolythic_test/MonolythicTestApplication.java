package com.example.monolythic_test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MonolythicTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(MonolythicTestApplication.class, args);
	}

}
